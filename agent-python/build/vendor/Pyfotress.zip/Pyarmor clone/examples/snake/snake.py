"""PyFortress Snake - a tkinter Snake game used to demonstrate protection.

Run:            python snake.py          (playable window)
Self-test:      python snake.py --selftest   (headless logic test, exit 0/1)
"""
import random
import sys

GRID_W, GRID_H = 28, 20
CELL = 24
SPEED_MS = 90
TITLE = "PyFortress Snake - protected build demo"
COLOR_BG = "#101418"
COLOR_SNAKE = "#39d353"
COLOR_HEAD = "#c9f76f"
COLOR_FOOD = "#ff5d5d"
COLOR_TEXT = "#9aa4b2"

UP, DOWN, LEFT, RIGHT = (0, -1), (0, 1), (-1, 0), (1, 0)
OPPOSITE = {UP: DOWN, DOWN: UP, LEFT: RIGHT, RIGHT: LEFT}


class Game:
    def __init__(self, seed=None):
        self.rng = random.Random(seed)
        self.reset()

    def reset(self):
        cx, cy = GRID_W // 2, GRID_H // 2
        self.snake = [(cx - 1, cy), (cx, cy), (cx + 1, cy)]
        self.direction = RIGHT
        self.pending = []
        self.score = 0
        self.alive = True
        self.food = self._spawn_food()

    def _spawn_food(self):
        free = [(x, y) for x in range(GRID_W) for y in range(GRID_H)
                if (x, y) not in self.snake]
        return self.rng.choice(free) if free else None

    def turn(self, new_dir):
        if new_dir != OPPOSITE[self.direction]:
            self.pending.append(new_dir)

    def step(self):
        if not self.alive:
            return
        if self.pending:
            d = self.pending.pop(0)
            if d != OPPOSITE[self.direction]:
                self.direction = d
        hx, hy = self.snake[-1]
        dx, dy = self.direction
        nx, ny = hx + dx, hy + dy
        if not (0 <= nx < GRID_W and 0 <= ny < GRID_H) or (nx, ny) in self.snake[:-1]:
            self.alive = False
            return
        self.snake.append((nx, ny))
        if (nx, ny) == self.food:
            self.score += 10
            self.food = self._spawn_food()
        else:
            self.snake.pop(0)


def run_selftest():
    """Headless logic verification for protected builds. Returns exit code."""
    g = Game(seed=1234)
    assert len(g.snake) == 3 and g.score == 0 and g.alive
    # steer into the food deterministically
    ate = False
    for i in range(2000):
        fx, fy = g.food
        hx, hy = g.snake[-1]
        if hx != fx:
            g.turn(RIGHT if fx > hx else LEFT)
        elif hy != fy:
            g.turn(DOWN if fy > hy else UP)
        g.step()
        if g.score >= 10:
            ate = True
            break
    assert ate, "snake never ate food in 2000 steps"
    assert len(g.snake) == 4, "snake did not grow after eating"

    # wall collision kills
    g2 = Game(seed=7)
    g2.snake = [(0, 0), (1, 0), (2, 0)]
    g2.direction = LEFT
    g2.step()
    assert not g2.alive, "wall collision did not kill"

    # self collision kills: head moving up into its own body segment
    g3 = Game(seed=7)
    g3.snake = [(5, 4), (6, 4), (6, 5)]   # tail, body, head
    g3.direction = UP
    g3.step()
    assert not g3.alive, "self collision did not kill"

    # random survival run
    g4 = Game(seed=99)
    dirs = [UP, DOWN, LEFT, RIGHT]
    steps = 0
    for i in range(500):
        g4.turn(dirs[i % 4])
        g4.step()
        steps += 1
        if not g4.alive:
            break
    assert steps > 0
    print("SELFTEST OK: eat/grow, wall death, self-collision death, "
          "score=%d, survived %d steps" % (g4.score, steps))
    return 0


def run_gui():
    import tkinter as tk

    root = tk.Tk()
    root.title(TITLE)
    canvas = tk.Canvas(root, width=GRID_W * CELL, height=GRID_H * CELL,
                       bg=COLOR_BG, highlightthickness=0)
    canvas.pack()
    status = tk.Label(root, text="Arrows to steer - ESC to quit", fg=COLOR_TEXT, bg=COLOR_BG)
    status.pack(fill="x")

    game = Game()

    def draw():
        canvas.delete("all")
        if game.food:
            fx, fy = game.food
            canvas.create_rectangle(fx * CELL + 3, fy * CELL + 3,
                                    (fx + 1) * CELL - 3, (fy + 1) * CELL - 3,
                                    fill=COLOR_FOOD, width=0)
        for i, (x, y) in enumerate(game.snake):
            color = COLOR_HEAD if i == len(game.snake) - 1 else COLOR_SNAKE
            canvas.create_rectangle(x * CELL + 1, y * CELL + 1,
                                    (x + 1) * CELL - 1, (y + 1) * CELL - 1,
                                    fill=color, width=0)
        status.config(text="score: %d   length: %d" % (game.score, len(game.snake)))

    def tick():
        game.step()
        if not game.alive:
            canvas.create_text(GRID_W * CELL // 2, GRID_H * CELL // 2,
                               text="GAME OVER - score %d" % game.score,
                               fill="white", font=("Consolas", 18))
            return
        draw()
        root.after(SPEED_MS, tick)

    keymap = {"Up": UP, "Down": DOWN, "Left": LEFT, "Right": RIGHT}

    def on_key(event):
        if event.keysym == "Escape":
            root.destroy()
            return
        d = keymap.get(event.keysym)
        if d:
            game.turn(d)

    root.bind("<Key>", on_key)
    draw()
    root.after(SPEED_MS, tick)
    root.mainloop()


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if "--selftest" in argv:
        return run_selftest()
    run_gui()
    return 0


if __name__ == "__main__":
    sys.exit(main())
