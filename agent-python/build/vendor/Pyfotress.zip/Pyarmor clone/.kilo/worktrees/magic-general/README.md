# PyFortress

**Free, unlimited protection for your Python programs.** PyFortress turns a
normal `.py` file (or a whole folder of them) into an encrypted copy that:

- runs exactly like the original,
- keeps your source code, secret strings and internal names hidden,
- refuses to run if someone tampers with it,
- can stop working after a chosen number of days or on a different PC,
- and can be packed into a single ready-to-run `.exe`.

No account, no build limits, no license server - everything runs locally on
your machine. Pure-stdlib crypto (ChaCha20 + HMAC-SHA256), Python 3.10+.

## Quick start (beginners)

1. **Windows:** double-click **Start PyFortress.bat**.
   **Any OS:** open a terminal in this folder and run `python -m pyfortress`.
2. Choose **1) Protect a program** and answer the questions:
   - pick the file to protect (or type a path),
   - pick a protection level (see the table below),
   - name the result (default `dist_<your file's name>`),
   - choose whether you also want a `.exe`,
   - optionally lock it to this PC, add an expiry, and write a checksum receipt.
3. Your protected program appears in a `dist_<name>` folder. Your original
   file is never modified.

If you built a `.exe`, you can copy that single file anywhere - no Python
needed on the other machine. If you didn't, keep the whole `dist_<name>`
folder together and run it with `python dist_<name>/<name>.py`.

## Protection levels

| Level | What it does |
|---|---|
| **Light** | Encrypts the code. Fast; internal names stay visible. |
| **Standard** | Encryption + all text strings hidden + docstrings stripped. *Recommended.* |
| **Strong** | Standard + internal names renamed (RFT) + anti-debug guards + import armor. |
| **Maximum** | Strong + wrap mode: each function's code re-encrypts itself whenever it is not running. |

## Extras the wizard offers

- **Standalone .exe** - one single file (PyInstaller), a folder with a .exe
  (starts faster), or a Nuitka-compiled exe (slowest build, leanest result).
- **Lock to this PC** - the program reads a hardware fingerprint and refuses
  to run anywhere else (menu option 3 shows the fingerprints).
- **Expiry** - the program stops working N days after it was built.
- **Checksum receipt** - a `checksums.txt` with the SHA-256 hash of every
  output file, so you can prove later that nothing was modified.

## What's in the output folder

```
dist_<name>/
  <name>.py            the protected entry file (a tiny bootstrap)
  fortress_runtime/    the encrypted payload + decryption runtime
  <name>.exe           if you asked for an exe
  checksums.txt        if you asked for a receipt
```

A file called `.fortress-build.json` is written next to the project when you
build. It holds the build's master keys - **keep it private**. It is what
lets you issue license keys for builds that use `--outer` (advanced).

## Command line reference (advanced)

The menu covers everything most people need. Under the hood it calls:

```
python -m pyfortress                       open the guided menu
python -m pyfortress menu                  same thing
python -m pyfortress protect INPUT... [-O DIR] [options]
python -m pyfortress key gen [-e DAYS|DATE] [-b DEV] [--bind-data D] [--period 30s|10m|2h] [-O DIR]
python -m pyfortress verify DIST --entry FILE [INPUT...] [--selftest-args ...]
python -m pyfortress hdinfo                hardware fingerprints for -b
python -m pyfortress doctor                toolchain status
```

Useful `protect` options: `--obf-code 2` (deep bytecode obfuscation),
`--mix-str` / `--no-mix-str`, `--rft` / `--no-rft`, `--wrap`, `--private`,
`--restrict`, `--assert-import`, `--assert-call`, `--antidebug`,
`--strip-docstrings`, `-e 30` (expiry), `-b FINGERPRINT` (device lock),
`--outer` (keys live in a separate `fortress.key` file instead of the build),
`--pack onefile|onedir`, `--nuitka`, `--native` (compile the runtime to
native code with Cython - needs a C compiler), `--name BUNDLE`.

## How it works

1. **Transform** each module's AST: identifier renaming (scope-aware, with
   safety nets for dunder/`__all__`/reflection-heavy code), string encryption
   (`__ffs__` decoder), optional wrap-mode stubs, assert armor.
2. **Compile** to bytecode and serialize a per-module meta blob; encrypt it
   with a per-module ChaCha20 key derived via HKDF-SHA256 from a per-build
   master key; MAC with a per-build HMAC key (encrypt-then-MAC - tampering
   is refused at load time).
3. **Emit** a bootstrap file per module plus a `fortress_runtime` package
   containing the keys (XOR-obfuscated in the pure tier), the container
   codec, license enforcement, and guards.
4. At **runtime** the bootstrap decrypts metadata in memory, executes the
   protected bytecode, and enforces the license checks. Plaintext never
   touches disk.

Keys are per build: two builds of the same source cannot decrypt each other.

## Honest limits

- In the pure-Python tier the embedded keys are obfuscated, not unextractable;
  a determined attacker with full control of the machine can eventually pull
  them. Use `--native` (Cython) to move the runtime into compiled code.
- Renaming (RFT) is deliberately conservative: names that appear as string
  literals, dunders, `__all__` entries and reflection-heavy modules are left
  alone, so behavior stays identical.
- Restrict mode checks who imported a module; it is not a sandbox.
- The GUI smoke test is a live-window check, not a formal proof.

## Development

```
python -m pytest tests/ -q
```
