"""RFT behavior tests: transformed code must behave identically."""
import ast, os, sys, textwrap
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from pyfortress.transforms import rft


def transform_and_run(src, modname="m1"):
    tree = ast.parse(src)
    info = rft.decide(rft.analyze(tree), modname)
    new = rft.apply(tree, info)
    ns = {"__name__": modname}
    exec(compile(new, "<t>", "exec"), ns)
    return ns, info


def test_scoping():
    src = textwrap.dedent('''
        import os
        __all__ = ["public_api"]
        counter = 0
        _private_data = [1, 2, 3]
        def public_api(n, scale=2):
            total = 0
            for item in _private_data:
                total += item * scale
            return total + n
        def _hidden(a, b=5, *rest, key=None, **kw):
            local = a + b
            def inner(z):
                nonlocal local
                local += z
                return local
            inner(1)
            global counter
            counter += 1
            squares = [x * x for x in rest if x > 0]
            pairs = [(x, y) for x in rest for y in _private_data if y > 1]
            mapping = {k: v for k, v in kw.items()}
            walrus = [y for y in squares if (m := y % 2) == 0 and m > 0]
            lam = lambda q, r=3: q + r + local
            class Helper:
                attr = 1
                def method(self, val):
                    return val + self.attr
            return (_hidden2(local, key=key) + len(mapping) + len(walrus)
                    + lam(2) + Helper().method(1) + len(pairs))
        def _hidden2(x, key=None):
            return x * 2
        keepme = 42
        class Widget:
            count = 0
            def __init__(self, name):
                self.name = name
                Widget.count += 1
            def label(self):
                return self.name
        def main():
            w = Widget("x")
            return public_api(3), _hidden(1, key=2, extra=3), w.label(), counter, keepme
    ''')
    ns, info = transform_and_run(src)
    mn = info.module_renames
    res = ns[mn["main"]]()
    assert res == (15, 29, "x", 1, 42), res
    assert "public_api" not in mn and "keepme" in mn and "Widget" in mn
    assert ns["public_api"](3) == 15
    assert len(mn) >= 6
    return info


def test_defaults_and_decorators():
    src = textwrap.dedent('''
        import functools
        BASE = 10
        def _deco(fn):
            @functools.wraps(fn)
            def wrapper(*a, **k):
                return fn(*a, **k) + 1
            return wrapper
        @_deco
        def _calc(v, inc=BASE):
            return v + inc
        def main():
            return _calc(5)
    ''')
    ns, info = transform_and_run(src)
    assert ns[info.module_renames["main"]]() == 16, ns[info.module_renames["main"]]()
    return info


def test_nested_comprehensions():
    src = textwrap.dedent('''
        FACTOR = 3
        def _work(rows):
            matrix = [[c * FACTOR for c in row] for row in rows]
            flat = {k: [v * k for v in row] for k, row in enumerate(rows)}
            gen = sum(x for x in (y for y in range(3)))
            return matrix, flat, gen
        def main():
            return _work([[1, 2], [3]])
    ''')
    ns, info = transform_and_run(src)
    res = ns[info.module_renames["main"]]()
    assert res[0] == [[3, 6], [9]] and res[1] == {0: [0, 0], 1: [3]} and res[2] == 3, res
    return info


def test_string_safety_net():
    src = textwrap.dedent('''
        import sys
        def _target():
            return 1
        def _other():
            return getattr(sys, "platform") != ""
        MARKER = "target"
        def main():
            return _target()
    ''')
    ns, info = transform_and_run(src)
    # exact-match safety net: a bind literally named like a string stays put
    assert ns[info.module_renames["main"]]() == 1
    assert ns[info.module_renames["_target"]]() == 1
    return info


def test_risky_module_not_renamed():
    src = textwrap.dedent('''
        _dyn = {"a": 1}
        def _get(k):
            return globals()["_dyn"][k]
        def main():
            return _get("a")
    ''')
    ns, info = transform_and_run(src)
    assert info.module_renames == {}, info.module_renames
    assert ns[info.a.module_scope.binds and "main" or "main"]() == 1
    return info


if __name__ == "__main__":
    i1 = test_scoping(); print("scoping OK")
    i2 = test_defaults_and_decorators(); print("decorators OK")
    i3 = test_nested_comprehensions(); print("nested comps OK")
    i4 = test_string_safety_net(); print("string safety OK")
    i5 = test_risky_module_not_renamed(); print("risky-module guard OK")
    print("ALL RFT TESTS PASSED")
