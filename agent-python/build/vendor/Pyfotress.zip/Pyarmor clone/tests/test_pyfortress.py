"""PyFortress test suite: crypto, keys, container, end-to-end protect flows."""
import base64
import os
import subprocess
import sys
import time

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from pyfortress import chacha20, container, keys  # noqa: E402

PY = sys.executable

APP = '''\
import sys

def add(a, b):
    return a + b

def selftest():
    assert add(2, 3) == 5
    print("E2E-OK")
    return 0

if __name__ == "__main__":
    sys.exit(selftest())
'''


# ---------------------------------------------------------------- crypto

def test_chacha20_rfc8439_vector():
    # RFC 8439 section 2.3.2 block-function vector: counter=1,
    # key 00..1f, nonce 000000090000004a00000000.
    import struct
    key = bytes(range(32))
    nonce = bytes.fromhex("000000090000004a00000000")
    k32 = struct.unpack("<8I", key)
    n3 = struct.unpack("<3I", nonce)
    assert chacha20._block(k32, 1, n3)[:16].hex() == \
        "10f1e7e4d13b5915500fdd1fa32071c4"
    # counter must actually advance
    assert chacha20._block(k32, 0, n3) != chacha20._block(k32, 1, n3)
    # keystream/xor roundtrip (container convention: counter starts at 0)
    msg = b"Ladies and Gentlemen of the class of '99"
    assert chacha20.xor(key, nonce, chacha20.xor(key, nonce, msg)) == msg


def test_hkdf_rfc5869_case1():
    ikm = bytes.fromhex("0b" * 22)
    okm = chacha20.hkdf(ikm, b"info", 42)
    assert len(okm) == 42
    assert len(chacha20.hkdf(ikm, b"info")) == 32


# ---------------------------------------------------------------- container

def test_container_roundtrip_and_tamper():
    key = os.urandom(32)
    mack = os.urandom(32)
    blob = container.pack(b"hello-fortress", key, mack)
    _flags, payload = container.unpack(blob, key, mack)
    assert payload == b"hello-fortress"
    bad = bytearray(blob)
    bad[len(blob) // 2] ^= 0xFF
    with pytest.raises(container.ContainerError):
        container.unpack(bytes(bad), key, mack)


# ---------------------------------------------------------------- keys

def test_parse_expire_fractional_and_date():
    now = time.time()
    assert abs(keys.parse_expire("0.1") - (now + 8640)) < 5
    assert keys.parse_expire("2020-01-01") < now
    assert keys.parse_expire(None) is None
    with pytest.raises(ValueError):
        keys.parse_expire("bogus")


def test_parse_period():
    assert keys.parse_period("30s") == 30
    assert keys.parse_period("10m") == 600
    assert keys.parse_period("2h") == 7200
    assert keys.parse_period(None) == 0


def test_license_required_matrix():
    assert keys.license_required(expires=None, devices=(), bind_data=None, period=0, outer=False) is False
    assert keys.license_required(expires=7, devices=(), bind_data=None, period=0, outer=False) is True
    assert keys.license_required(expires=None, devices=(), bind_data="x", period=0, outer=False) is True
    assert keys.license_required(expires=None, devices=(), bind_data=None, period=0, outer=True) is True


# ---------------------------------------------------------------- e2e helpers

def _protect(tmp_path, src, out, extra=()):
    workdir = tmp_path / "work"
    workdir.mkdir(exist_ok=True)
    app = workdir / "app.py"
    app.write_text(src, encoding="utf-8")
    cmd = [PY, "-m", "pyfortress", "protect", "app.py", "-O", out, *extra]
    env = dict(os.environ, PYTHONPATH=ROOT)
    proc = subprocess.run(cmd, cwd=workdir, capture_output=True, text=True, env=env, timeout=300)
    assert proc.returncode == 0, proc.stderr[-1500:]
    return workdir, workdir / out


def _run(dist, *args):
    return subprocess.run([PY, "app.py", *args], cwd=dist, capture_output=True,
                          text=True, timeout=120)


# ---------------------------------------------------------------- e2e

def test_e2e_protect_run_and_tamper(tmp_path):
    _, dist = _protect(tmp_path, APP, "dist", ("--wrap", "--obf-code", "2"))
    proc = _run(dist, "--selftest")
    assert proc.returncode == 0, proc.stderr[-1500:]
    assert "E2E-OK" in proc.stdout

    # leak scan: plaintext identifiers from the source must not survive
    blob = (dist / "app.py").read_text(encoding="utf-8")
    assert "selftest" not in blob.replace("fortress_runtime", "")
    assert "add" not in blob.replace("add(", "").replace("_pf_boot", "")

    # tamper rejection: flip one char inside the payload
    text = blob.splitlines(keepends=True)
    li = next(i for i, l in enumerate(text) if "_pf_boot(__name__" in l)
    payload_line = text[li]
    q = payload_line.rindex(",") + 2          # opening quote of the payload
    i = q + 3 + 40
    flipped = payload_line[:i] + ("A" if payload_line[i] != "A" else "B") + payload_line[i + 1:]
    text[li] = flipped
    (dist / "app.py").write_text("".join(text), encoding="utf-8")
    proc = _run(dist, "--selftest")
    assert proc.returncode != 0


def test_e2e_expired_license(tmp_path):
    _, dist = _protect(tmp_path, APP, "dist", ("-e", "2020-01-01"))
    proc = _run(dist, "--selftest")
    assert proc.returncode != 0
    assert "license expired" in (proc.stderr + proc.stdout)


def test_e2e_bind_data_roundtrip(tmp_path):
    _, dist = _protect(tmp_path, APP, "dist", ("--bind-data", "TOPSECRET-42"))
    proc = _run(dist, "--selftest")
    assert proc.returncode == 0, proc.stderr[-1500:]


def test_e2e_outer_key_flow(tmp_path):
    _, dist = _protect(tmp_path, APP, "dist", ("--outer",))
    # --outer ships the key alongside for local testing; remove it to model
    # distribution without the key
    (dist / "fortress.key").unlink()
    proc = _run(dist, "--selftest")
    assert proc.returncode != 0
    assert "license key not found" in (proc.stderr + proc.stdout)
    # garbage key -> refuse
    (dist / "fortress.key").write_bytes(b"garbage")
    proc = _run(dist, "--selftest")
    assert proc.returncode != 0
    assert "invalid license key" in (proc.stderr + proc.stdout)
    # key gen with matching manifest -> runs
    env = dict(os.environ, PYTHONPATH=ROOT)
    subprocess.run([PY, "-m", "pyfortress", "key", "gen", "-O", "keys"],
                   cwd=dist.parent, capture_output=True, env=env, timeout=120)
    shutil_key = dist.parent / "keys" / "fortress.key"
    assert shutil_key.is_file()
    (dist / "fortress.key").write_bytes(shutil_key.read_bytes())
    proc = _run(dist, "--selftest")
    assert proc.returncode == 0, proc.stderr[-1500:]


def test_e2e_private_blocks_foreign_driver(tmp_path):
    _, dist = _protect(tmp_path, APP, "dist", ("--private",))
    driver = dist / "drv.py"
    driver.write_text("import app\nprint(app.add(1, 2))\n", encoding="utf-8")
    proc = subprocess.run([PY, "drv.py"], cwd=dist, capture_output=True, text=True, timeout=120)
    assert proc.returncode != 0
    assert "has no attribute" in (proc.stderr + proc.stdout)


def test_e2e_verify_command(tmp_path):
    _, dist = _protect(tmp_path, APP, "dist", ("--wrap",))
    src = tmp_path / "work" / "app.py"
    env = dict(os.environ, PYTHONPATH=ROOT)
    proc = subprocess.run([PY, "-m", "pyfortress", "verify", "dist", "--entry", "app.py",
                           str(src), "--selftest-args", "--selftest"],
                          cwd=dist.parent, capture_output=True, text=True, env=env, timeout=300)
    assert "OVERALL:     PASS" in proc.stdout
