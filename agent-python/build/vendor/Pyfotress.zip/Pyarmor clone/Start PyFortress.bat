@echo off
title PyFortress
cd /d "%~dp0"
python -m pyfortress
echo.
pause
